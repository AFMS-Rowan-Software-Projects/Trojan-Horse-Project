This package is created for educational purposes,
to demostrate the work of a payload in a vulnerable application 
which will establish sensitive communication to an external server 
controlled by the attackers 

It has class Trojan with Cryptofunctions
as well as client and server code for port listening 
and data transmitting